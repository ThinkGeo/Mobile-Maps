=========================================
      ThinkGeo Product Center 12.0
           For .NET Core 3.0
=========================================

Thank you for downloading ThinkGeo Product Center 12.0.  Product Center serves
as a central point for you to install, evaluate, purchase, and activate
ThinkGeo products.  To begin using Product Center, follow these steps:

  1. Ensure that you have installed .NET Core 3.0 from Microsoft, which can be
     downloaded at the web address below.

     https://dotnet.microsoft.com/download/dotnet-core/current

     To decide whether to download the .NET Core SDK vs. Runtime:

        a. If you will be developing .NET Core applications with ThinkGeo UI
           on your computer, select the "Build apps - SDK" package.

        b. If you will only be activating or deactivating ThinkGeo licenses on
           your computer, you can select the "Run apps - Runtime" package.

  2. Right-click the ThinkGeoProductCenter12.zip file and choose "Properties".
     At the bottom of the "General" tab, if you see an "Unblock" button, 
     click it to ensure Windows does not block Product Center from launching.

  3. Unzip the ThinkGeoProductCenter12.zip file into a folder of your choice 
     on your computer.

  4. Double-click Start_ThinkGeo_Product_Center.bat to launch Product Center.
     You'll be notified if the required .NET Core version isn't detected.

  5. Click "Log in" in the top right corner and log in using your ThinkGeo
     account username and password.

From here, you can click on any ThinkGeo UI product on the left side of the
application window to begin an evaluation, or activate a product for which you
have purchased a license.

If you need to develop for .NET Framework 4 instead of .NET Core 3.0, please
download ThinkGeo Product Center 10.0 from the direct link below:

https://cdn.thinkgeo.com/downloads/ThinkGeoProductCenter.zip

If you have any questions, feel free to contact us.

  Email:   sales@thinkgeo.com
  Phone:   +1-785-727-4133
  Forums:  https://community.thinkgeo.com

And finally, thank you for developing with ThinkGeo GIS controls for .NET!

ThinkGeo LLC
8501 Wade Blvd Ste 550
Frisco, TX 75034
https://thinkgeo.com